const express = require("express")
const app = express();
const mongoose = require("mongoose");
const bodyparser = require("body-parser");

app.use(bodyparser.json());

mongoose.connect('mongodb+srv://kiran:1234567abc@cluster0-0rjyg.mongodb.net/sampleDB?retryWrites=true&w=majority', {useNewUrlParser: true, useUnifiedTopology: true }, () => {
    console.log("db connected");
});

require("./order")
const Order = mongoose.model("Order")

//to add new order
app.post("/order", (req,res) => {
    var neworder = {
        name: req.body.name,
        comment: req.body.comment
    }

    var order = new Order(neworder);
    order.save().then(() => {
        res.send("order Created")
    }).catch((err) => {
        if(err){
            throw err
        }
    })
})

// to update existing order reply
app.put("/orderreply/:id", (req,res) => {
    Order.findByIdAndUpdate(req.params.id, {
        reply: req.body.reply
    }, {new: true})
    .then(note => {
        if(!note) {
            return res.status(404).send({
                message: "Note not found with id " + req.params.id
            });
        }
        res.send(note);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Note not found with id " + req.params.id
            });                
        }
        return res.status(500).send({
            message: "Error updating note with id " + req.params.id
        });
    });
})

//to get all orders
app.get("/orders", (req, res) => {
    Order.find().then((orders) =>{
        res.json(orders)
    }).catch((err) => {
        if(err) {
            throw err
        }
    })
})

app.listen("4545", () => {
    console.log("Up and running - orders service")
})