const mongoose = require("mongoose")

var orderSchema = mongoose.Schema({
    "name" : { type: String },
    "comment" : { type: String },
    "reply" : { type: String },
  });

mongoose.model("Order", orderSchema)